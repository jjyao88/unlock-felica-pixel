## v2.0 - 2023/10/19
- feat: Support KernelSU solution
- fix: Attempt to fix Pixel 8 Pro incompatibility?
- chore: Reduce package size

## v1.0 - 2023/09/24
- Initial release